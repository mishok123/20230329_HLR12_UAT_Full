/****** Object:  Table [dbo].[SPMS_SPOnlineRateSetup_tmp]    Script Date: 3/29/2023 12:04:53 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SPMS_SPOnlineRateSetup_tmp]') AND type in (N'U'))
DROP TABLE [dbo].[SPMS_SPOnlineRateSetup_tmp]
GO

/****** Object:  Table [dbo].[SPMS_SPOnlineRateSetup_tmp]    Script Date: 3/29/2023 12:04:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SPMS_SPOnlineRateSetup_tmp](
	[AutoPrimaryKey] [decimal](18, 0) IDENTITY(1,1) NOT NULL,
	[SPTypeID] [varchar](3) NOT NULL,
	[Limit] [decimal](18, 0) NOT NULL,
	[FromMonth] [int] NOT NULL,
	[ToMonth] [int] NOT NULL,
	[Rate] [decimal](5, 2) NOT NULL,
	[UploadDate] [datetime] NOT NULL,
	[EffectiveDate] [datetime] NOT NULL,
	[DivisionID] [char](3) NULL,
	[BankID] [char](3) NULL,
	[MakerID] [varchar](20) NULL,
	[MakeDate] [datetime] NULL,
	[CheckerID] [varchar](20) NULL,
	[CheckDate] [datetime] NULL,
	[CheckerComment] [varchar](max) NULL,
 CONSTRAINT [PK_SPMS_SPOnlineRateSetup_tmp] PRIMARY KEY CLUSTERED 
(
	[AutoPrimaryKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


/****** Object:  Table [dbo].[SPMS_SPOnlineRateSetup]    Script Date: 3/29/2023 12:04:58 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SPMS_SPOnlineRateSetup]') AND type in (N'U'))
DROP TABLE [dbo].[SPMS_SPOnlineRateSetup]
GO

/****** Object:  Table [dbo].[SPMS_SPOnlineRateSetup]    Script Date: 3/29/2023 12:04:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SPMS_SPOnlineRateSetup](
	[AutoPrimaryKey] [decimal](18, 0) NOT NULL,
	[SPTypeID] [varchar](3) NOT NULL,
	[Limit] [decimal](18, 0) NOT NULL,
	[FromMonth] [int] NOT NULL,
	[ToMonth] [int] NOT NULL,
	[Rate] [decimal](5, 2) NOT NULL,
	[UploadDate] [datetime] NOT NULL,
	[EffectiveDate] [datetime] NOT NULL,
	[DivisionID] [char](3) NOT NULL,
	[BankID] [char](3) NOT NULL,
	[MakerID] [varchar](20) NOT NULL,
	[MakeDate] [datetime] NOT NULL,
	[CheckerID] [varchar](20) NOT NULL,
	[CheckDate] [datetime] NOT NULL,
	[CheckerComment] [varchar](max) NULL,
 CONSTRAINT [PK_SPMS_SPOnlineRateSetup] PRIMARY KEY CLUSTERED 
(
	[AutoPrimaryKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


